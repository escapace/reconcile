// Does one metadata object with toJSON (e.g. a lazily emitted layout table) slow the document?
import { fixtures } from '../harness/corpus.mjs'
const [name, codecPath] = process.argv.slice(2)
const { stringify } = await import(codecPath)
const tree = JSON.parse(stringify(fixtures[name]()))
function time(fn, budget = 250) { for (let i = 0; i < 5; i++) fn(); let n = 0; const t0 = performance.now(); let t; do { fn(); n++ } while ((t = performance.now() - t0) < budget); return (t / n) * 1000 }
let sink = 0
const shapes = tree[1]
const lazyFirst = [{ toJSON: () => shapes }, tree[1], tree[2]]          // toJSON object before the payload
const lazyLast = [tree[0], tree[1], tree[2], { toJSON: () => shapes }]   // toJSON object after the payload
const plain4 = [tree[0], tree[1], tree[2], shapes]
const r = {
  plain: time(() => { sink ^= JSON.stringify(plain4).length }),
  toJSONLast: time(() => { sink ^= JSON.stringify(lazyLast).length }),
  toJSONFirst: time(() => { sink ^= JSON.stringify(lazyFirst).length }),
  replacerOnlyAtRoot: time(() => { sink ^= JSON.stringify(plain4, function (k, v) { return v }).length }),
}
console.log(name.padEnd(14), Object.entries(r).map(([k, v]) => `${k} ${v.toFixed(0)}`).join('  '))
