// Upper-bound cost of native callback paths (exploratory; ignores the observation contract).
import { fixtures } from '../harness/corpus.mjs'
const [name, codecPath] = process.argv.slice(2)
const { stringify, parse } = await import(codecPath)
const value = fixtures[name](); const text = stringify(value); const tree = JSON.parse(text)
function time(fn, budget = 250) { for (let i = 0; i < 5; i++) fn(); let n = 0; const t0 = performance.now(); let t; do { fn(); n++ } while ((t = performance.now() - t0) < budget); return (t / n) * 1000 }
let sink = 0
// One-loop encoder: stringify the source with a replacer that memoizes identities (first
// occurrence inline, later occurrences as references) — no Map/Set/natives, no holes.
function oneLoop(v) {
  const ids = new Map()
  return JSON.stringify(v, function (key, x) {
    if (x !== null && typeof x === 'object') { const id = ids.get(x); if (id !== undefined) return { $: id }; ids.set(x, ids.size) }
    return x
  })
}
class Row { constructor(r) { this.r = r } toJSON() { return this.r } }
const wrapped = [tree[0], tree[1], tree[2].map((r) => new Row(r))]
const rows = {
  'stringify(transport)': time(() => { sink ^= JSON.stringify(tree).length }),
  'stringify(transport, identity replacer)': time(() => { sink ^= JSON.stringify(tree, (k, v) => v).length }),
  'stringify(rows with toJSON)': time(() => { sink ^= JSON.stringify(wrapped).length }),
  'codec stringify (capture + native)': time(() => { sink ^= stringify(value).length }),
  'one-loop replacer encoder (upper bound)': (() => { try { return time(() => { sink ^= oneLoop(value).length }) } catch (e) { return NaN } })(),
  'JSON.parse(text)': time(() => { sink ^= JSON.parse(text) === null }),
  'JSON.parse(text, identity reviver)': time(() => { sink ^= JSON.parse(text, (k, v) => v) === null }),
  'codec parse': time(() => { sink ^= parse(text) === null }),
}
console.log(name, JSON.stringify(Object.fromEntries(Object.entries(rows).map(([k, v]) => [k, Math.round(v)]))))
