// Variant B (tree-inlined) vs A (flat) at wire level. Exploratory, single process.
// Slots: 0 literal, 1 reference (repeat), 2 inline (first occurrence, payload written in place).
// Layouts interned by (kind, keys?, kinds); descriptors list one layout per composite in preorder.
import { fixtures } from '../harness/corpus.mjs'
const [name, form] = process.argv.slice(2)
const value = fixtures[name]()
const lit = (v) => v === null || typeof v === 'string' || typeof v === 'boolean' || (typeof v === 'number' && Number.isFinite(v) && !Object.is(v, -0))
function encode(root) {
  const ids = new Map(), layouts = [], layoutIds = new Map(), desc = [], flat = []
  const lay = (sig, entry) => { let id = layoutIds.get(sig); if (id === undefined) { id = layouts.length; layoutIds.set(sig, id); layouts.push(entry) } return id }
  function slot(v, kinds) {
    if (lit(v)) { kinds.push(0); return v }
    if (typeof v !== 'object') { kinds.push(1); return special(v) }
    const id = ids.get(v); if (id !== undefined) { kinds.push(1); return id }
    if (form === 'tree') { kinds.push(2); return node(v) }
    kinds.push(1); return node(v)
  }
  function special(v) { const k = 's' + String(v) + (Object.is(v, -0) ? '0' : ''); let id = ids.get(k); if (id === undefined) { id = desc.length; ids.set(k, id); desc.push(lay('C', ['C'])); const p = typeof v === 'bigint' ? String(v) : [undefined, NaN, Infinity, -Infinity].indexOf(v); if (form === 'flat') flat.push(p); else spec.push(p) } return id }
  const spec = []
  function node(o) {
    const id = desc.length; ids.set(o, id); const at = desc.push(-1) - 1; const kinds = [], p = []
    if (form === 'flat') flat.push(p)
    let tag, keys
    if (Array.isArray(o)) { tag = 'A'; for (let i = 0; i < o.length; i++) p.push(slot(o[i], kinds)) }
    else if (o instanceof Map) { tag = 'M'; for (const [k, v] of o) { p.push(slot(k, kinds)); p.push(slot(v, kinds)) } }
    else if (o instanceof Set) { tag = 'S'; for (const v of o) p.push(slot(v, kinds)) }
    else { tag = 'R'; keys = Object.keys(o); for (const k of keys) p.push(slot(o[k], kinds)) }
    desc[at] = lay(tag + (keys ? keys.join('\0') : '') + '|' + kinds.join(''), [tag, kinds, keys])
    return form === 'flat' ? id : p
  }
  const rk = []; const r = slot(root, rk)
  return JSON.stringify(form === 'flat' ? [rk[0], r, layouts, desc, flat] : [rk[0], r, layouts, desc, spec])
}
const C = [undefined, NaN, Infinity, -Infinity]
function decodeFlat(text) {
  const [rk, r, layouts, desc, payloads] = JSON.parse(text); const out = new Array(payloads.length)
  for (let i = 0; i < payloads.length; i++) { const L = layouts[desc[i]], t = L[0]; out[i] = t === 'A' ? payloads[i] : t === 'R' ? {} : t === 'M' ? new Map() : t === 'S' ? new Set() : typeof payloads[i] === 'string' ? BigInt(payloads[i]) : C[payloads[i]] }
  for (let i = 0; i < payloads.length; i++) { const L = layouts[desc[i]], t = L[0], k = L[1], p = payloads[i], o = out[i]
    if (t === 'A') { for (let j = 0; j < k.length; j++) if (k[j] === 1) p[j] = out[p[j]] }
    else if (t === 'R') { const keys = L[2]; for (let j = 0; j < keys.length; j++) o[keys[j]] = k[j] === 1 ? out[p[j]] : p[j] }
    else if (t === 'M') { for (let j = 0; j < p.length; j += 2) o.set(k[j] ? out[p[j]] : p[j], k[j + 1] ? out[p[j + 1]] : p[j + 1]) }
    else if (t === 'S') { for (let j = 0; j < p.length; j++) o.add(k[j] ? out[p[j]] : p[j]) } }
  return rk ? out[r] : r
}
function decodeTree(text) {
  const [rk, r, layouts, desc, spec] = JSON.parse(text); const out = new Array(desc.length)
  // Pass 1 (preorder, explicit stack): allocate every node and record its payload, assigning ids by preorder.
  const pay = new Array(desc.length); let next = 0; const stack = []
  const visit = (p) => { const id = next++; const L = layouts[desc[id]]; pay[id] = p; const t = L[0]; out[id] = t === 'A' ? p : t === 'R' ? {} : t === 'M' ? new Map() : t === 'S' ? new Set() : undefined; stack.push(id, 0) }
  if (rk === 2) visit(r)
  while (stack.length) { const pos = stack.pop(), id = stack.pop(); const k = layouts[desc[id]][1], p = pay[id]
    let j = pos; while (j < k.length && k[j] !== 2) { if (k[j] === 1 && layouts[desc[p[j]]]?.[0] === 'C') {} j++ }
    if (j < k.length) { stack.push(id, j + 1); visit(p[j]); pay[id + 0] = p; continue } }
  // constants
  let s = 0; for (let i = 0; i < desc.length; i++) if (layouts[desc[i]][0] === 'C') { const v = spec[s++]; out[i] = typeof v === 'string' ? BigInt(v) : C[v] }
  // Pass 2: fill (inline children resolve by preorder id order: recompute ids by walking again)
  // For simplicity, map inline payload objects to ids.
  const idOf = new Map(); for (let i = 0; i < desc.length; i++) if (pay[i] !== undefined) idOf.set(pay[i], i)
  for (let i = 0; i < desc.length; i++) { const p = pay[i]; if (p === undefined) continue; const L = layouts[desc[i]], t = L[0], k = L[1], o = out[i]
    const res = (j) => k[j] === 0 ? p[j] : k[j] === 1 ? out[p[j]] : out[idOf.get(p[j])]
    if (t === 'A') { for (let j = 0; j < k.length; j++) if (k[j] !== 0) p[j] = res(j) }
    else if (t === 'R') { const keys = L[2]; for (let j = 0; j < keys.length; j++) o[keys[j]] = res(j) }
    else if (t === 'M') { for (let j = 0; j < p.length; j += 2) o.set(res(j), res(j + 1)) }
    else if (t === 'S') { for (let j = 0; j < p.length; j++) o.add(res(j)) } }
  return rk === 0 ? r : rk === 1 ? out[r] : out[0]
}
function time(fn, budget = 250) { for (let i = 0; i < 5; i++) fn(); let n = 0; const t0 = performance.now(); let t; do { fn(); n++ } while ((t = performance.now() - t0) < budget); return (t / n) * 1000 }
const text = encode(value); const decode = form === 'flat' ? decodeFlat : decodeTree; let sink = 0
const layoutsCount = JSON.parse(text)[2].length
const enc = time(() => { sink ^= encode(value).length }), dec = time(() => { sink ^= decode(text) === null }), parse = time(() => { sink ^= JSON.parse(text) === null })
console.log([name.padEnd(16), form.padEnd(4), enc.toFixed(0).padStart(7), dec.toFixed(0).padStart(7), parse.toFixed(0).padStart(7), String(text.length).padStart(8), String(layoutsCount).padStart(5)].join(' '))
