// What does native JSON.stringify observe on a source graph when used as the traversal?
const log = []
const spy = (t, label) => new Proxy(t, {
  get(o, k, r) { log.push(`get ${label}.${String(k)}`); return Reflect.get(o, k, r) },
  has(o, k) { log.push(`has ${label}.${String(k)}`); return Reflect.has(o, k) },
  ownKeys(o) { log.push(`ownKeys ${label}`); return Reflect.ownKeys(o) },
  getOwnPropertyDescriptor(o, k) { log.push(`gopd ${label}.${String(k)}`); return Reflect.getOwnPropertyDescriptor(o, k) },
  getPrototypeOf(o) { log.push(`proto ${label}`); return Reflect.getPrototypeOf(o) },
})
const record = { a: 1 }
Object.defineProperty(record, 'hidden', { value: 2, enumerable: false })
const value = spy({ r: spy(record, 'record'), list: spy([1, , 3], 'list') }, 'root')
const calls = []
JSON.stringify(value, function (key, v) { calls.push(`replacer ${JSON.stringify(key)} holderHas=${key === '' ? '-' : Object.prototype.hasOwnProperty.call(this, key)} value=${typeof v === 'object' ? (Array.isArray(v) ? 'array' : 'object') : String(v)}`); return v })
console.log('stringify+replacer observations:\n  ' + log.join('\n  '))
console.log('replacer calls:\n  ' + calls.join('\n  '))
const order = []
JSON.parse('{"a":{"b":1},"c":[2]}', (k, v) => { order.push(k === '' ? '(root)' : k); return v })
console.log('reviver order:', order.join(' -> '))
