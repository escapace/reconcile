// Wire-level microbenchmark (exploratory, not decision evidence): two transport forms built
// from the same graph with positional kinds (no in-band sentinels).
//  rows: payload of a record = [values...] with keys in an interned layout; arrays = [values...]
//  objs: payload of a record = {key: value...}; arrays = [values...]
// Both: node payloads in one array, descriptors (layout ids) in a parallel int array,
// references = node ids in slots the layout marks as references (refs listed per layout).
import { fixtures } from '../harness/corpus.mjs'
const [name, form] = process.argv.slice(2)
const value = fixtures[name]()
const isLit = (v) => v === null || (typeof v !== 'object' && typeof v !== 'undefined' && typeof v !== 'bigint' && !(typeof v === 'number' && (!Number.isFinite(v) || Object.is(v, -0))))
function encode(root) {
  const ids = new Map(), payloads = [], desc = [], layouts = [], layoutIds = new Map(), consts = new Map()
  const stack = []
  function layout(sig, entry) { let id = layoutIds.get(sig); if (id === undefined) { id = layouts.length; layoutIds.set(sig, id); layouts.push(entry) } return id }
  function constNode(v) { const k = typeof v === 'bigint' ? 'b' + v : Object.is(v, -0) ? '-0' : String(v); let id = consts.get(k); if (id === undefined) { id = payloads.length; consts.set(k, id); payloads.push(typeof v === 'bigint' ? String(v) : Object.is(v, -0) ? 4 : v === undefined ? 0 : Number.isNaN(v) ? 1 : v > 0 ? 2 : 3); desc.push(layout(typeof v === 'bigint' ? 'B' : 'C', [typeof v === 'bigint' ? 'B' : 'C'])) } return id }
  function slot(v, refs, i) { if (isLit(v)) return v; refs.push(i); if (typeof v !== 'object' || v === null) return constNode(v); return node(v) }
  function node(o) { let id = ids.get(o); if (id !== undefined) return id; id = payloads.length; ids.set(o, id); payloads.push(null); desc.push(-1); stack.push([o, id]); return id }
  const rootRef = !isLit(root); const r = rootRef ? (typeof root === 'object' && root !== null ? node(root) : constNode(root)) : root
  while (stack.length) {
    const [o, id] = stack.pop(); const refs = []
    if (Array.isArray(o)) { const p = new Array(); for (let i = 0; i < o.length; i++) p.push(slot(o[i], refs, i)); payloads[id] = p; desc[id] = layout('A' + refs.join(','), ['A', refs]) }
    else if (o instanceof Map) { const p = []; for (const [k, v] of o) { p.push(slot(k, refs, p.length)); p.push(slot(v, refs, p.length)) } payloads[id] = p; desc[id] = layout('M' + refs.join(','), ['M', refs]) }
    else if (o instanceof Set) { const p = []; for (const v of o) p.push(slot(v, refs, p.length)); payloads[id] = p; desc[id] = layout('S' + refs.join(','), ['S', refs]) }
    else { const keys = Object.keys(o)
      if (form === 'objs') { const p = {}; for (let i = 0; i < keys.length; i++) { const k = keys[i]; const v = slot(o[k], refs, i); if (k === '__proto__') Object.defineProperty(p, k, { value: v, enumerable: true, writable: true, configurable: true }); else p[k] = v } payloads[id] = p; desc[id] = layout('O' + keys.join('\0') + '|' + refs.join(','), ['O', refs.map((i) => keys[i])]) }
      else { const p = []; for (let i = 0; i < keys.length; i++) p.push(slot(o[keys[i]], refs, i)); payloads[id] = p; desc[id] = layout('R' + keys.join('\0') + '|' + refs.join(','), ['R', keys, refs]) } }
  }
  return JSON.stringify([rootRef ? 1 : 0, r, layouts, desc, payloads])
}
const C = [undefined, NaN, Infinity, -Infinity, -0]
function decode(text) {
  const [rootRef, r, layouts, desc, payloads] = JSON.parse(text)
  const out = new Array(payloads.length)
  for (let i = 0; i < payloads.length; i++) { const L = layouts[desc[i]], t = L[0], p = payloads[i]
    if (t === 'A' || t === 'O') out[i] = p // zero-copy: the parsed array/object is the value
    else if (t === 'R') out[i] = {}; else if (t === 'M') out[i] = new Map(); else if (t === 'S') out[i] = new Set();
    else if (t === 'C') out[i] = C[p]; else out[i] = BigInt(p) }
  for (let i = 0; i < payloads.length; i++) { const L = layouts[desc[i]], t = L[0], p = payloads[i], o = out[i]
    if (t === 'A') { const refs = L[1]; if (process.env.VALIDATE) { let n = 0; for (let j = 0; j < p.length; j++) { if (n < refs.length && refs[n] === j) { n++; continue } const v = p[j]; if (typeof v === 'object' && v !== null) throw new Error('literal') } } for (let j = 0; j < refs.length; j++) p[refs[j]] = out[p[refs[j]]] }
    else if (t === 'O') { const refs = L[1]; for (let j = 0; j < refs.length; j++) o[refs[j]] = out[o[refs[j]]] }
    else if (t === 'R') { const keys = L[1], refs = L[2]; let n = 0; for (let j = 0; j < keys.length; j++) { let v = p[j]; if (n < refs.length && refs[n] === j) { v = out[v]; n++ } const k = keys[j]; if (k === '__proto__') Object.defineProperty(o, k, { value: v, enumerable: true, writable: true, configurable: true }); else o[k] = v } }
    else if (t === 'M') { const refs = new Set(L[1]); for (let j = 0; j < p.length; j += 2) o.set(refs.has(j) ? out[p[j]] : p[j], refs.has(j + 1) ? out[p[j + 1]] : p[j + 1]) }
    else if (t === 'S') { const refs = new Set(L[1]); for (let j = 0; j < p.length; j++) o.add(refs.has(j) ? out[p[j]] : p[j]) } }
  return rootRef ? out[r] : r
}
function time(fn, budget = 300) { for (let i = 0; i < 5; i++) fn(); let n = 0; const t0 = performance.now(); let t; do { fn(); n++ } while ((t = performance.now() - t0) < budget); return (t / n) * 1000 }
const text = encode(value); let sink = 0
const enc = time(() => { sink ^= encode(value).length }), dec = time(() => { sink ^= decode(text) === null }), parse = time(() => { sink ^= JSON.parse(text) === null })
console.log([name.padEnd(16), form.padEnd(4), enc.toFixed(0).padStart(7), dec.toFixed(0).padStart(7), parse.toFixed(0).padStart(7), String(text.length).padStart(8)].join(' '))
