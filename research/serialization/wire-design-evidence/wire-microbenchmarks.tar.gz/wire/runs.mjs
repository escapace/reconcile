// Size of run-length kind descriptors per fixture (no timing): literal / reference / hole runs.
import { fixtures } from '../harness/corpus.mjs'
const lit = (v) => v === null || ['string', 'boolean'].includes(typeof v) || (typeof v === 'number' && Number.isFinite(v) && !Object.is(v, -0))
for (const [name, make] of Object.entries(fixtures)) {
  const seen = new Set(), stack = [make()], layouts = new Set(); let runs = 0, containers = 0, slots = 0
  while (stack.length) { const o = stack.pop(); if (o === null || typeof o !== 'object' || seen.has(o)) continue; seen.add(o)
    let seq = []
    if (Array.isArray(o)) { for (let i = 0; i < o.length; i++) seq.push(!(i in o) ? 2 : lit(o[i]) ? 0 : 1); for (const v of o) stack.push(v) }
    else if (o instanceof Map) { for (const [k, v] of o) { seq.push(lit(k) ? 0 : 1, lit(v) ? 0 : 1); stack.push(k, v) } }
    else if (o instanceof Set) { for (const v of o) { seq.push(lit(v) ? 0 : 1); stack.push(v) } }
    else if (Object.getPrototypeOf(o) === Object.prototype || Object.getPrototypeOf(o) === null) { const ks = Object.keys(o); for (const k of ks) { seq.push(lit(o[k]) ? 0 : 1); stack.push(o[k]) } seq.unshift(ks.join('\0')) }
    else continue
    containers++; slots += seq.length
    const r = []; for (const k of seq) { if (r.length && r.at(-1)[0] === k) r.at(-1)[1]++; else r.push([k, 1]) } runs += r.length; layouts.add(JSON.stringify(r))
  }
  console.log(name.padEnd(18), 'containers', String(containers).padStart(6), 'slots', String(slots).padStart(7), 'runs', String(runs).padStart(6), 'distinct layouts', String(layouts.size).padStart(5))
}
