// Canonicity fuzz for the positional wire: mutate one or two JSON values of a valid document
// (scalars, or whole arrays), then require each outcome to be a rejection (ParseInputInvalid
// or a native error) or an acceptance whose decoded graph re-encodes to exactly the mutated
// document. Accepted mismatches are printed for classification (native folding or key order).
// usage: node canonfuzz.mjs <candidate codec> [mutationsPerFixture]
import { fixtures } from './corpus.mjs'
const [c, per = '200'] = process.argv.slice(2)
const B = await import(c)
let seed = 4242; const rnd = (n) => ((seed = (seed * 1103515245 + 12345) >>> 0) % n)
const pool = [0, 1, 2, 3, 5, 7, -1, -0, 0.5, 1e400, -1e400, 4294967295, 4294967296, null, true, false, '', 'x', '0', '-0', '01', '__proto__', [], [0], [1], [0, 1], [1, 0], {}, [[]], 9007199254740993]
function paths(node, path, out) { out.push(path); if (Array.isArray(node)) node.forEach((x, i) => paths(x, path.concat(i), out)) }
function setAt(tree, path, value) { if (path.length === 0) return value; let t = tree; for (let i = 0; i < path.length - 1; i++) t = t[path[i]]; t[path.at(-1)] = value; return tree }
let checks = 0, accepted = 0, rejected = 0, native = 0
const mismatches = []
for (const [name, make] of Object.entries(fixtures)) {
  const text = B.stringify(make())
  if (text.length > 120000) continue
  const all = []; paths(JSON.parse(text), [], all)
  for (let m = 0; m < +per; m++) {
    let tree = JSON.parse(text)
    const k = 1 + rnd(2)
    for (let j = 0; j < k; j++) tree = setAt(tree, all[rnd(all.length)], structuredClone(pool[rnd(pool.length)]))
    const mutated = JSON.stringify(tree)
    checks++
    let value
    try { value = B.parse(mutated) } catch (e) {
      if (e?.cause?.type === 'ParseInputInvalid') rejected++
      else native++
      continue
    }
    accepted++
    let again
    try { again = B.stringify(value) } catch (e) { again = 'throws ' + e }
    if (again !== mutated) {
      let i = 0; while (mutated[i] === String(again)[i]) i++
      mismatches.push({ name, at: i, mutated: mutated.slice(Math.max(0, i - 60), i + 80), again: String(again).slice(Math.max(0, i - 60), i + 80) })
    }
  }
}
console.log('mutations', checks, 'accepted', accepted, 'ParseInputInvalid', rejected, 'native errors', native, 'accepted non-canonical', mismatches.length)
for (const x of mismatches.slice(0, 12)) console.log(JSON.stringify(x))
