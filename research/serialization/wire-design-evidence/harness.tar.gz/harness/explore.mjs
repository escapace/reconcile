// Exploratory single-process latency table. Not decision evidence.
import { fixtures, equivalent } from './corpus.mjs'
const arms = process.argv.slice(2)
const mods = {}
for (const a of arms) mods[a] = await import(`../bundles/${a}/codec.mjs`)
const only = process.env.ONLY?.split(',')
function time(fn, budget = 60) { for (let i = 0; i < 3; i++) fn(); let n = 0; const t0 = performance.now(); let t; do { fn(); n++ } while ((t = performance.now() - t0) < budget); return (t / n) * 1000 }
const rows = []
for (const [name, make] of Object.entries(fixtures)) {
  if (only && !only.includes(name)) continue
  const value = make(); const row = { name }
  for (const a of arms) {
    const { stringify, parse } = mods[a]
    if (a.startsWith("devalue") && name === "deep-2000") { row[a] = "SKIP stack overflow"; continue }
    let text
    try { text = stringify(value); equivalent(value, parse(text)) } catch (e) { row[a] = 'FAIL ' + String(e.message).slice(0, 30); continue }
    let sink = 0
    const enc = time(() => { sink ^= stringify(value).length })
    const dec = time(() => { sink ^= parse(text) === null })
    row[a] = `${enc.toFixed(1)} / ${dec.toFixed(1)}  (${text.length})`
  }
  rows.push(row); console.log(JSON.stringify(row))
}
