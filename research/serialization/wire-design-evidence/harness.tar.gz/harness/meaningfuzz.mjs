// Relaxed-decoding fuzz for the positional wire: mutate one or two JSON values of a valid
// document. Each outcome must be a rejection (ParseInputInvalid, or a native constructor error)
// or an acceptance whose graph re-encodes to a document that decodes to an equivalent graph and
// re-encodes identically (stringify output is canonical even when accepted input is not).
// usage: node meaningfuzz.mjs <candidate codec> [mutationsPerFixture]
import { fixtures, equivalent } from './corpus.mjs'
const [c, per = '200'] = process.argv.slice(2)
const B = await import(c)
let seed = 4242; const rnd = (n) => ((seed = (seed * 1103515245 + 12345) >>> 0) % n)
const pool = [0, 1, 2, 3, 5, 7, -1, -0, 0.5, 1e400, -1e400, 4294967295, 4294967296, null, true, false, '', 'x', '0', '-0', '01', '__proto__', [], [0], [1], [0, 1], [1, 0], {}, [[]], 9007199254740993]
function paths(node, path, out) { out.push(path); if (Array.isArray(node)) node.forEach((x, i) => paths(x, path.concat(i), out)) }
function setAt(tree, path, value) { if (path.length === 0) return value; let t = tree; for (let i = 0; i < path.length - 1; i++) { t = t[path[i]]; if (!Array.isArray(t)) return tree } t[path.at(-1)] = value; return tree }
let checks = 0, accepted = 0, rejected = 0, noncanonical = 0
const native = new Map()
for (const [name, make] of Object.entries(fixtures)) {
  const text = B.stringify(make())
  if (text.length > 120000) continue
  const all = []; paths(JSON.parse(text), [], all)
  for (let m = 0; m < +per; m++) {
    let tree = JSON.parse(text)
    const k = 1 + rnd(2)
    for (let j = 0; j < k; j++) tree = setAt(tree, all[rnd(all.length)], structuredClone(pool[rnd(pool.length)]))
    const mutated = JSON.stringify(tree)
    checks++
    let value
    try { value = B.parse(mutated) } catch (e) {
      if (e?.cause?.type === 'ParseInputInvalid') rejected++
      else { native.set(e?.name, (native.get(e?.name) ?? 0) + 1); if (process.env.SHOW) console.log(name, e?.name, e?.message, (e?.stack ?? '').split('\n')[1]?.trim()) }
      continue
    }
    accepted++
    const again = B.stringify(value)
    if (again !== mutated) noncanonical++
    const twice = B.parse(again)
    equivalent(twice, value)
    if (B.stringify(twice) !== again) throw new Error(`${name}: re-encoding not stable: ${mutated.slice(0, 200)}`)
  }
}
console.log('mutations', checks, 'accepted', accepted, '(non-canonical', noncanonical + ')', 'ParseInputInvalid', rejected, 'native errors', JSON.stringify(Object.fromEntries(native)))
