// Differential observation-trace checker: baseline vs candidate codec bundles.
// For every fixture, records each observable source operation (proxy traps, getters,
// iterator next/return, destructuring reads) and injects a unique throw at each
// observation index k. Arms must agree on trace, wire text and thrown identity for all k.
// Wire-change variant: arms may emit different wires; traces, thrown identities and decoded
// graphs must agree, and the candidate must re-emit its own wire from the decoded graph.
// usage: node difftrace-wire.mjs <baseline codec.mjs> <candidate codec.mjs>
import assert from 'node:assert/strict'
import { equivalent } from './corpus.mjs'
const [basePath, candPath] = process.argv.slice(2)
const arms = [await import(basePath), await import(candPath)]
let log = [], throwAt = Infinity
class Injected extends Error {}
function obs(event) { log.push(event); if (log.length === throwAt) throw new Injected('injected@' + throwAt) }
function spy(target, label) {
  return new Proxy(target, {
    get(t, k, r) { obs(`get ${label}.${String(k)}`); return Reflect.get(t, k, r) },
    has(t, k) { obs(`has ${label}.${String(k)}`); return Reflect.has(t, k) },
    ownKeys(t) { obs(`ownKeys ${label}`); return Reflect.ownKeys(t) },
    getPrototypeOf(t) { obs(`proto ${label}`); return Reflect.getPrototypeOf(t) },
    getOwnPropertyDescriptor(t, k) { obs(`gopd ${label}.${String(k)}`); return Reflect.getOwnPropertyDescriptor(t, k) },
  })
}
function iter(items, label, closeLog = true) {
  let i = 0
  return {
    [Symbol.iterator]() { obs(`iter ${label}`); return this },
    next() { obs(`next ${label}#${i}`); return i < items.length ? { done: false, value: items[i++] } : { done: true, value: undefined } },
    ...(closeLog ? { return() { obs(`return ${label}`); return { done: true } } } : {}),
  }
}
const fixtures = {
  'proxied-records': () => spy({ a: 1, b: spy({ c: 'x', d: spy([1, spy({ e: null }, 'e'), 3], 'arr') }, 'b'), f: undefined, g: -2.5, h: 7n }, 'root'),
  'getter-mutations': () => {
    const arr = [1, 2, 3]
    const o = { get first() { obs('getter first'); arr.push({ late: true }); return arr }, get second() { obs('getter second'); delete o.third; return { n: 1 } }, third: 3, get fourth() { obs('getter fourth'); o.extra = 9; return 4 } }
    return spy(o, 'o')
  },
  'sparse-proxied-array': () => { const a = [0, , { x: 1 }, , 4]; a.length = 9; return spy(a, 'sp') },
  'growing-array': () => { const a = [1, 2]; const o = { get grow() { obs('getter grow'); a[5] = 'tail'; return 0 } }; a[1] = o; return spy(a, 'grow') },
  'map-custom-entries': () => {
    const m = new Map([[1, 1]]); const k1 = { k: 1 }, v1 = spy({ v: 1 }, 'v1')
    m.entries = () => { obs('entries()'); return iter([spy([k1, v1], 'entry0'), spy(['two', { get z() { obs('getter z'); return 2 } }], 'entry1'), spy([k1, 3], 'entry2')], 'mapit') }
    return { m, k1 }
  },
  'set-custom-values': () => {
    const s = new Set(); const shared = { s: 1 }
    s.values = () => { obs('values()'); return iter([shared, spy({ inner: shared }, 'inner'), shared, 5, undefined], 'setit') }
    return [s, shared]
  },
  'native-map-revisit': () => {
    const m = new Map(); const key = 'k'
    m.set(key, { get v() { obs('getter v'); if (m.has(key)) { m.delete(key); m.set(key, 'again') } return 1 } })
    m.set('other', 2)
    return m
  },
  'close-on-unsupported': () => { const s = new Set(); s.values = () => { obs('values()'); return iter([1, { bad: Symbol('x') }, 3], 'closeit') }; return { before: spy({ p: 1 }, 'before'), s } },
  'close-on-throw-in-map-value': () => {
    const m = new Map(); m.entries = () => { obs('entries()'); return iter([['a', { get boom() { obs('getter boom'); throw new Error('app') } }], ['b', 2]], 'boomit') }
    return m
  },
  'iterator-no-return': () => { const s = new Set(); s.values = () => { obs('values()'); return iter([{ get t() { obs('getter t'); return 1 } }, 2], 'noret', false) }; return s },
  'natives-shadowed': () => {
    const buf = new ArrayBuffer(8); const view = new Uint8Array(buf, 2, 3); const date = new Date(5)
    Object.defineProperty(view, 'buffer', { get() { obs('shadow buffer'); return null } })
    date.getTime = () => { obs('shadow getTime'); return 0 }
    const url = new URL('https://e.test/?q=1')
    return spy({ view, buf, date, url, params: url.searchParams, again: view }, 'nat')
  },
  'proto-proxy-unsupported': () => [1, spy(Object.create({ notPlain: true }), 'weird'), 3],
  'deep-proxied-chain': () => { let x = spy({ end: true }, 'end'); for (let i = 0; i < 30; i++) x = spy({ i, next: x, arr: [i, x] }, 'n' + i); return x },
  'record-symbol-added-late': () => { const o = { get a() { obs('getter a'); o[Symbol('late')] = 1; return 1 } }; return o },
}
function run(arm, make) {
  log = []; const value = make(); log = [] // construction observations excluded
  let outcome
  try { outcome = { text: arm.stringify(value) } } catch (e) { outcome = { error: e instanceof Injected ? e.message : `${e?.name}:${e?.cause?.type ?? ''}:${e?.message}` } }
  return { trace: log, outcome }
}
// Wires differ by design; compare everything else.
function shape(r) { return { trace: r.trace, error: r.outcome.error, ok: r.outcome.text !== undefined }
}
let checks = 0
const refolded = []
for (const [name, make] of Object.entries(fixtures)) {
  throwAt = Infinity
  const free = arms.map((arm) => run(arm, make))
  assert.deepEqual(shape(free[1]), shape(free[0]), `${name}: free run differs`)
  checks++
  if (free[0].outcome.text !== undefined) {
    const parsed = arms.map((arm, i) => arm.parse(free[i].outcome.text))
    equivalent(parsed[1], parsed[0]) // throws on any graph difference
    // Re-emission differs only where native Map/Set folding or own-key order changed the graph.
    if (arms[1].stringify(parsed[1]) !== free[1].outcome.text) refolded.push(name)
  }
  for (let k = 1; k <= free[0].trace.length + 1; k++) {
    throwAt = k
    const r = arms.map((arm) => run(arm, make))
    assert.deepEqual(shape(r[1]), shape(r[0]), `${name}: fault at ${k} differs`)
    checks++
  }
  throwAt = Infinity
  console.log(name.padEnd(28), 'observations', String(free[0].trace.length).padStart(4), free[0].outcome.error ?? 'ok')
}
console.log('differential checks passed:', checks, 're-emission differs (folded/reordered source):', refolded)
