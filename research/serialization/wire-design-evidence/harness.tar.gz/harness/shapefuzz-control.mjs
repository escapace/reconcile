// Shape-interning fuzz: random record key sequences (prefixes, extensions, permutations,
// lone surrogates); candidate shapes table must equal the baseline's byte for byte (wire-change variant).
const [b, c, n = '3000'] = process.argv.slice(2)
const A = await import(b), B = await import(c)
let seed = 7; const rnd = (k) => ((seed = (seed * 1103515245 + 12345) >>> 0) % k)
const alphabet = ['a', 'b', 'c', 'd', '\ud800', '0', '1', '__proto__', '', 'a,b', '"']
let total = 0
for (let t = 0; t < +n; t++) {
  const records = []
  const count = 1 + rnd(12)
  for (let r = 0; r < count; r++) {
    const o = {}; const len = rnd(7)
    for (let k = 0; k < len; k++) Object.defineProperty(o, alphabet[rnd(alphabet.length)], { value: k, enumerable: true, configurable: true, writable: true })
    records.push(o)
  }
  // Repeat some records' shapes in a different order to exercise lookups after splits.
  for (let r = 0; r < count; r++) if (rnd(2)) records.push(Object.assign({}, records[rnd(count)]))
  const x = JSON.stringify(JSON.parse(A.stringify(records))[1]), y = JSON.stringify(controlShapes(JSON.parse(B.stringify(records))))
  if (x !== y) { console.error('MISMATCH', JSON.stringify(records.map(Object.keys)), x, y); process.exit(1) }
  total++
}
console.log('shape fuzz identical:', total)
// Shapes in the control table: after one layout id per node, a count, then length-framed keys.
function controlShapes([control, payloads]) {
  const shapes = []; let at = payloads.length + 1
  for (let s = 0; s < control[payloads.length]; s++) { const n = control[at]; shapes.push(control.slice(at + 1, at + 1 + n)); at += n + 1 }
  return shapes
}
