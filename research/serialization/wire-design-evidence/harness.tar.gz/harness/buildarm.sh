#!/usr/bin/env bash
# usage: buildarm.sh <name>  -> builds package lib and timing bundle into $S/bundles/<name>
set -euo pipefail
S=/tmp/claude-0/-home-user-reconcile/01c69311-58f1-5bf3-b92b-9a23b8bb1329/scratchpad
export PATH=/opt/nvm/versions/node/v24.22.0/bin:$PATH
cd "$S/arms/$1" && node --import tsx scripts/build.ts > /dev/null
cd "$S/harness" && node build-arm.mjs "$S/arms/$1/lib/neutral/index.js" "$S/bundles/$1"
