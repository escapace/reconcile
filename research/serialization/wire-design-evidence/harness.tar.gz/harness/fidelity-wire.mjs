// Graph fidelity across a wire change: for every corpus fixture the candidate's decoded graph
// must equal the baseline's, and re-encoding the candidate's decoded graph must reproduce its
// wire exactly (canonical documents), except where native folding changed the graph.
// usage: node fidelity-wire.mjs <baseline codec> <candidate codec>
import { fixtures, equivalent } from './corpus.mjs'
const [b, c] = process.argv.slice(2)
const A = await import(b), B = await import(c)
let checked = 0, bytesA = 0, bytesB = 0
const differs = []
for (const [name, make] of Object.entries(fixtures)) {
  let ta, tb
  try { ta = A.stringify(make()) } catch (e) { ta = e }
  try { tb = B.stringify(make()) } catch (e) { tb = e }
  if (typeof ta !== 'string' || typeof tb !== 'string') {
    if (typeof ta === 'string' || typeof tb === 'string' || ta.name !== tb.name) throw new Error(`${name}: outcome differs`)
    console.log(name.padEnd(28), 'both reject', ta.name); continue
  }
  const ga = A.parse(ta), gb = B.parse(tb)
  equivalent(gb, ga)
  if (B.stringify(gb) !== tb) differs.push(name)
  bytesA += ta.length; bytesB += tb.length; checked++
  console.log(name.padEnd(28), String(ta.length).padStart(9), String(tb.length).padStart(9), (tb.length / ta.length).toFixed(3))
}
console.log('fidelity fixtures', checked, 'text chars baseline', bytesA, 'candidate', bytesB, 'ratio', (bytesB / bytesA).toFixed(3), 'non-idempotent', differs)
