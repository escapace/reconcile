#!/usr/bin/env bash
# usage: mkarm.sh <name> <base-arm>  -> copies $S/arms/<base>/src to $S/arms/<name> (fresh), links node_modules
set -euo pipefail
S=/tmp/claude-0/-home-user-reconcile/01c69311-58f1-5bf3-b92b-9a23b8bb1329/scratchpad
name=$1; base=${2:-control}
rm -rf "$S/arms/$name"; mkdir -p "$S/arms/$name"
(cd "$S/arms/$base" && tar --exclude=./node_modules --exclude=./lib -cf - .) | tar -xf - -C "$S/arms/$name"
ln -sfn /home/user/reconcile/node_modules "$S/arms/$name/node_modules"
