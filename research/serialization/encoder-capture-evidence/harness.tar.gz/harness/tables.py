#!/usr/bin/env python3
import json, gzip, statistics as st, pathlib, sys
R = pathlib.Path(sys.argv[1])
def load(d, name='summary.json.gz'): return json.loads(gzip.open(R / d / name).read())
F3, F4, H4, FP, DV, DD = load('F3'), load('F4'), load('H4'), load('FP1'), load('DV1', 'summary-vs-devalue.json.gz'), load('F3d')
fx = list(dict.fromkeys(k.split(':')[0] for k in F3))
def pooled(arm, cell, *rs): return [x for r in rs for x in r[cell]['arms'][arm]['ratios']]
def fmt(xs): return f"{st.median(xs):.2f} ({min(xs):.2f}–{max(xs):.2f})"
print('| Fixture | Baseline encode µs | Encode | Consumed encode | Round trip | Decode-only | Copy encode range | History encode | History round trip | Fast-path encode |')
print('|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|')
for f in fx:
    e = f + ':enc'
    ref = st.median(F3[e]['ref_abs_us'] + F4[e]['ref_abs_us'])
    copy = pooled('copy', e, F3, F4)
    print(f"| `{f}` | {ref:,.0f} | {fmt(pooled('final', e, F3, F4))} | {fmt(pooled('final', f+':encc', F3, F4))} | {fmt(pooled('final', f+':rt', F3, F4))} | "
          f"{st.median(DD[f+':dec']['arms']['final']['ratios']):.2f} | {min(copy):.2f}–{max(copy):.2f} | {H4[e]['arms']['final']['median']:.2f} | {H4[f+':rt']['arms']['final']['median']:.2f} | {FP[e]['arms']['final']['median']:.2f} |")
print()
print('| Fixture | Encode final/devalue | Decode final/devalue | Round trip final/devalue | Round trip baseline/devalue |')
print('|---|---:|---:|---:|---:|')
fd = list(dict.fromkeys(k.split(':')[0] for k in DV))
for f in fd:
    c = lambda op, arm='final': DV[f+':'+op]['arms'][arm]
    m = lambda x: f"{x['median']:.2f} ({x['min']:.2f}–{x['max']:.2f})"
    print(f"| `{f}` | {m(c('enc'))} | {m(c('dec'))} | {m(c('rt'))} | {c('rt','baseline')['median']:.2f} |")
