// usage: node --cpu-prof prof.mjs <libEntry> <fixture> <encode|decode> <ms>
import { fixtures } from './corpus.mjs'
const [entry, name, op, ms] = process.argv.slice(2)
const { stringify, parse } = await import(entry)
const value = fixtures[name](); const text = stringify(value)
let sink = 0; const t0 = performance.now(); let n = 0
while (performance.now() - t0 < +ms) { if (op === 'encode') sink ^= stringify(value).length; else sink ^= parse(text) === null; n++ }
console.error(name, op, ((performance.now() - t0) / n * 1000).toFixed(1), 'us/op', n)
