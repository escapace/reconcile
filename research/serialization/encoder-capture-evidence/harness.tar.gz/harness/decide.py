#!/usr/bin/env python3
"""Apply the pre-registered rule to one or more rounds' summary.json (from analyze.py --json).
A cell is FLAGGED in a round when arm median ratio > 1.03 and the arm's ratio range lies beyond the
copy's (arm min > copy max). A regression requires a flag in every round given.
usage: decide.py --arm final summary1.json [summary2.json ...]"""
import json, sys, argparse, math, statistics as st
ap = argparse.ArgumentParser(); ap.add_argument('--arm', required=True); ap.add_argument('--control', default='copy'); ap.add_argument('files', nargs='+')
a = ap.parse_args()
rounds = [json.load(open(f)) for f in a.files]
cells = sorted(set.intersection(*[set(r) for r in rounds]))
flags = {}; gains = {}; table = []
for c in cells:
    row = []
    for r in rounds:
        arm = r[c]['arms'].get(a.arm); ctl = r[c]['arms'].get(a.control)
        if arm is None: continue
        flag = arm['median'] > 1.03 and (ctl is None or arm['min'] > ctl['max'])
        gain = arm['median'] < 0.97 and (ctl is None or arm['max'] < ctl['min'])
        row.append((arm['median'], flag, gain, ctl['median'] if ctl else None))
    table.append((c, row))
    if row and all(x[1] for x in row): flags[c] = row
    if row and all(x[2] for x in row): gains[c] = row
print(f"cells {len(cells)}; rounds {len(rounds)}; arm {a.arm}")
print("REGRESSIONS (flagged in every round):", 'none' if not flags else '')
for c, row in flags.items(): print('  ', c, [round(x[0], 3) for x in row])
print("single-round flags:")
for c, row in table:
    if any(x[1] for x in row) and c not in flags: print('  ', c, [(round(x[0], 3), x[1]) for x in row])
print(f"CONFIRMED GAINS (beyond copy range in every round): {len(gains)} cells")
ops = {}
for c, row in table:
    op = c.split(':')[1]; ops.setdefault(op, []).append(math.exp(st.fmean(math.log(x[0]) for x in row)))
for op, xs in ops.items(): print(f"  {op}: geomean of per-cell ratios {math.exp(st.fmean(math.log(x) for x in xs)):.3f} (range {min(xs):.3f}-{max(xs):.3f}, n={len(xs)})")
