// Differential decode fuzzing: baseline vs candidate on valid wires and seeded token mutations.
// usage: node decodediff.mjs <baseline codec> <candidate codec> [mutationsPerFixture]
import assert from 'node:assert/strict'
import { fixtures } from './corpus.mjs'
const [b, c, per = '60'] = process.argv.slice(2)
const arms = [await import(b), await import(c)]
let seed = 12345; const rnd = (n) => ((seed = (seed * 1103515245 + 12345) >>> 0) % n)
const pool = ['-0', '1e400', '-1e400', '-1', '-2', '-5', '-6', '-7', '-8', '-1000000', '0.5', '-0.5', '-6.5', '2', 'null', 'true', '"x"', '"__proto__"', '[]', '[-7]', '[-7,1]', '[-7,-1]', '[-6,"12"]', '[-6,"-0"]', '[-6,"01"]', '[-6,"1e3"]', '[-6,12]', '{}', '[1,2,3]', '[-1]', '4294967295', '4294967296', '1.5', '-4294967301']
function outcome(arm, text) {
  try { const v = arm.parse(text); return { ok: arm.stringify(v) } } catch (e) { return { err: `${e?.name}:${e?.cause?.type ?? ''}:${e?.cause?.reason ?? e?.message}` } }
}
// Collect positions of every scalar slot in the transport tree (path list), mutate one or two.
function slots(node, path, out) { if (Array.isArray(node)) node.forEach((x, i) => slots(x, path.concat(i), out)); else out.push(path) }
function setAt(tree, path, raw) { let t = tree; for (let i = 0; i < path.length - 1; i++) t = t[path[i]]; t[path.at(-1)] = raw }
let checks = 0, same = 0, errs = 0
for (const [name, make] of Object.entries(fixtures)) {
  const text = arms[0].stringify(make())
  if (text.length > 300000) continue
  assert.deepEqual(outcome(arms[1], text), outcome(arms[0], text), name + ' valid'); checks++
  const tree = JSON.parse(text); const all = []; slots(tree, [], all)
  for (let m = 0; m < +per; m++) {
    const copy = JSON.parse(text); const k = 1 + rnd(2)
    for (let j = 0; j < k; j++) setAt(copy, all[rnd(all.length)], '\u0000' + pool[rnd(pool.length)])
    const mutated = JSON.stringify(copy).replace(/"\\u0000([^"\\]*(?:\\.[^"\\]*)*)"/g, (_, raw) => JSON.parse('"' + raw + '"'))
    const r0 = outcome(arms[0], mutated), r1 = outcome(arms[1], mutated)
    assert.deepEqual(r1, r0, `${name} mutation ${m}: ${mutated.slice(0, 200)}`)
    checks++; if (r0.err) errs++; else same++
  }
}
console.log('decode differential checks', checks, 'accepted', same, 'rejected', errs)
