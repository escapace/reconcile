#!/usr/bin/env python3
"""Sequential fresh-process measurement round. Wrap in scripts/bounded-check.py (295 s).
Never run concurrently with tests, builds, profilers or another benchmark."""
import argparse, json, os, random, subprocess, sys, time, hashlib, pathlib
HERE = pathlib.Path(__file__).resolve().parent
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
ap = argparse.ArgumentParser()
ap.add_argument('--arms', required=True, help='name=codec.mjs,...')
ap.add_argument('--manifest', required=True)
ap.add_argument('--fixtures', default='')
ap.add_argument('--reps', type=int, default=3)
ap.add_argument('--mode', choices=['isolated', 'history'], default='isolated')
ap.add_argument('--seed', type=int, default=1)
ap.add_argument('--deadline', type=float, default=280)
ap.add_argument('--node-flags', default='', help='extra space-separated node flags')
ap.add_argument('--out', required=True)
a = ap.parse_args()
start = time.monotonic()
out = pathlib.Path(a.out); out.mkdir(parents=True, exist_ok=False)
arms = [tuple(x.split('=', 1)) for x in a.arms.split(',')]
manifest = json.loads(pathlib.Path(a.manifest).read_text())
fixtures = a.fixtures.split(',') if a.fixtures else list(manifest['counts'])
node = os.environ.get('NODE', 'node')
design = {'arms': {n: {'path': p, 'sha256': sha(p)} for n, p in arms}, 'manifest_sha256': sha(a.manifest),
          'fixtures': fixtures, 'reps': a.reps, 'mode': a.mode, 'seed': a.seed, 'node': subprocess.run([node, '--version'], capture_output=True, text=True).stdout.strip(),
          'loadavg_start': os.getloadavg(), 'node_flags': a.node_flags, 'worker_sha256': sha(HERE / 'worker.mjs'), 'corpus_sha256': sha(HERE / 'corpus.mjs')}
(out / 'design.json').write_text(json.dumps(design, indent=1))
rng = random.Random(a.seed)
samples = open(out / 'samples.jsonl', 'w')
complete = True; launched = 0
units = fixtures if a.mode == 'isolated' else ['@history']
for rep in range(a.reps):
    order = units[:]; rng.shuffle(order)
    for fi, fixture in enumerate(order):
        k = (rep * len(order) + fi) % len(arms)
        seq = arms[k:] + arms[:k]
        if rep % 2: seq = seq[::-1]
        for pos, (name, path) in enumerate(seq):
            if time.monotonic() - start > a.deadline: complete = False; break
            seed = rng.randrange(1, 2**31)
            cmd = [node, '--harmony-temporal', '--stack-size=4000', *a.node_flags.split(), str(HERE / 'worker.mjs'), path, a.manifest, fixture, str(seed)]
            t0 = time.monotonic()
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=max(1, a.deadline - (time.monotonic() - start)))
            launched += 1
            rec = {'arm': name, 'rep': rep, 'pos': pos, 'fixture': fixture, 'seed': seed, 'exit': r.returncode, 'elapsed': time.monotonic() - t0, 'loadavg': os.getloadavg()}
            if r.returncode == 0: rec['data'] = json.loads(r.stdout)
            else: rec['stderr'] = r.stderr[-2000:]; complete = False
            samples.write(json.dumps(rec) + '\n'); samples.flush()
        if not complete: break
    if not complete: break
samples.close()
(out / 'receipt.json').write_text(json.dumps({'complete': complete, 'launched': launched, 'seconds': time.monotonic() - start, 'loadavg_end': os.getloadavg()}, indent=1))
print(json.dumps({'complete': complete, 'launched': launched, 'seconds': round(time.monotonic() - start, 1)}))
sys.exit(0 if complete else 3)
