// Retained 22-fixture corpus (unchanged, from research/serialization/interleaved-a) plus
// separately labelled supplemental fixtures for shapes named in the 2026-10-17 brief.
import { fixtures as retained, equivalent } from '/home/user/reconcile/research/serialization/interleaved-a/corpus.mjs'
export { equivalent }
const unicodeParts = ['ünïcødé', '日本語テキスト', 'emoji 😀🎉', 'quote " back \\ slash', 'ctl \u0001\u001f tab\t nl\n', 'lone \ud800 surrogate', 'ascii-plain']
export const supplemental = {
  'unicode-10k': () => Array.from({ length: 10000 }, (_, i) => unicodeParts[i % unicodeParts.length] + '-' + i),
  'long-strings': () => Array.from({ length: 200 }, (_, i) => ('lorem ipsum dolor sit amet ' + i + ' ').repeat(40)),
  'small-collections': () => Array.from({ length: 1000 }, (_, i) => ({ id: i, tags: new Set(['a', 'b', 'c' + (i % 7)]), counts: new Map([['x', i], ['y', i + 1], ['z', i + 2]]) })),
  'set-shared': () => { const pool = Array.from({ length: 1000 }, (_, i) => ({ id: i, name: 'n' + i })); return { pool, set: new Set(pool) } },
  'map-object-keys': () => { const keys = Array.from({ length: 2000 }, (_, i) => ({ k: i })); return new Map(keys.map((k, i) => [k, { v: i, label: 'v' + i }])) },
  'records-wide': () => Array.from({ length: 1000 }, (_, i) => { const o = {}; for (let k = 0; k < 20; k++) o['field' + k] = k % 3 === 0 ? 'text-' + i : k % 3 === 1 ? i + k : k % 2 === 0; return o }),
  'records-varied': () => Array.from({ length: 2000 }, (_, i) => { const o = { id: i }; for (let k = 0; k < 6; k++) if ((i >> k) & 1) o['opt' + k] = k; return o }),
  'nested-arrays': () => Array.from({ length: 2000 }, (_, i) => [i, i + 1, i + 2, i + 3, i + 4, 'x' + i, true, null]),
  'sparse-big': () => { const a = new Array(100000); for (let i = 0; i < 100000; i += 100) a[i] = i; return a },
}
// Diagnostic (2026-10-17, review finding): records used as dictionaries with unique key sequences.
export const dictionaries = {
  'dict-10k': () => { const o = {}; for (let i = 0; i < 10000; i++) o['key-' + i] = i; return o },
  'dict-records': () => Array.from({ length: 2000 }, (_, i) => { const o = {}; for (let j = 0; j < 5; j++) o['u' + i + '_' + j] = j; return o }),
}
// Diagnostic (W1 wire question): coordinates with negative fractional values.
export const negatives = {
  'geo-5k': () => Array.from({ length: 5000 }, (_, i) => ({ lat: -33.8 - i / 1e4, lon: -151.2 + i / 1e3, alt: i % 7 })),
}
export const fixtures = { ...retained, ...supplemental, ...dictionaries, ...negatives }
