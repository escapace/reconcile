// Differential observation test: base vs candidate codec bundle.
// Usage: node inline-differential.mjs <base.mjs> <cand.mjs> [fuzzCount=4000]
// Each case builds a fresh input twice (once per library) and compares
// (output text | error description) together with the full observation log.
const [base, cand, countArgument] = process.argv.slice(2)
const A = await import(base)
const B = await import(cand)
const fuzzCount = Number(countArgument ?? 4000)

function describeKey(key) {
  return typeof key === 'symbol' ? key.toString() : JSON.stringify(key)
}

function makeEnv() {
  const log = []
  const thrown = []
  const names = new Map()
  const env = {
    log,
    thrown,
    names,
    note(text) {
      log.push(text)
    },
    who(value) {
      if (value !== null && (typeof value === 'object' || typeof value === 'function'))
        return names.get(value) ?? '?'
      return typeof value
    },
    name(value, label) {
      names.set(value, label)
      return value
    },
    boom(label) {
      const error = { boom: label }
      thrown.push(error)
      return error
    },
    // Full logging proxy. Getter receivers are reported by name.
    watch(target, label) {
      const proxy = new Proxy(target, {
        get(t, key, receiver) {
          env.note(`${label}.get ${describeKey(key)} recv=${env.who(receiver)}`)
          return Reflect.get(t, key, receiver)
        },
        has(t, key) {
          env.note(`${label}.has ${describeKey(key)}`)
          return Reflect.has(t, key)
        },
        ownKeys(t) {
          env.note(`${label}.ownKeys`)
          return Reflect.ownKeys(t)
        },
        getPrototypeOf(t) {
          env.note(`${label}.getPrototypeOf`)
          return Reflect.getPrototypeOf(t)
        },
        getOwnPropertyDescriptor(t, key) {
          env.note(`${label}.gOPD ${describeKey(key)}`)
          return Reflect.getOwnPropertyDescriptor(t, key)
        },
        set(t, key, value, receiver) {
          env.note(`${label}.set ${describeKey(key)}`)
          return Reflect.set(t, key, value, receiver)
        },
        defineProperty(t, key, d) {
          env.note(`${label}.defineProperty ${describeKey(key)}`)
          return Reflect.defineProperty(t, key, d)
        },
        deleteProperty(t, key) {
          env.note(`${label}.deleteProperty ${describeKey(key)}`)
          return Reflect.deleteProperty(t, key)
        },
        isExtensible(t) {
          env.note(`${label}.isExtensible`)
          return Reflect.isExtensible(t)
        },
        preventExtensions(t) {
          env.note(`${label}.preventExtensions`)
          return Reflect.preventExtensions(t)
        },
        setPrototypeOf(t, p) {
          env.note(`${label}.setPrototypeOf`)
          return Reflect.setPrototypeOf(t, p)
        },
      })
      names.set(proxy, label)
      if (!names.has(target)) names.set(target, label + '#target')
      return proxy
    },
    // Wraps a native iterator with logged next/return.
    iter(label, inner, options = {}) {
      let steps = 0
      const it = {
        next() {
          env.note(`${label}.next recv=${env.who(this)}`)
          if (options.throwNextAt === steps++) throw env.boom(`${label}.next`)
          const result = inner.next()
          if (!result.done && options.wrapEntry) {
            const entry = result.value
            return { done: false, value: env.entry(`${label}.entry${steps}`, entry) }
          }
          return result
        },
        [Symbol.iterator]() {
          return this
        },
      }
      if (!options.noReturn)
        it.return = function () {
          env.note(`${label}.return recv=${env.who(this)}`)
          if (options.throwReturn) throw env.boom(`${label}.return`)
          return { done: true }
        }
      env.name(it, label + '.iterator')
      return it
    },
    // A Map entry as a custom iterable, so destructuring is observable.
    entry(label, pair) {
      return {
        [Symbol.iterator]() {
          env.note(`${label}[@@iterator]`)
          let i = 0
          const items = [...pair, 'extra']
          return {
            next() {
              env.note(`${label}.next ${i}`)
              return i < items.length ? { value: items[i++], done: false } : { done: true, value: undefined }
            },
            return() {
              env.note(`${label}.return`)
              return {}
            },
          }
        },
      }
    },
    loggedMap(label, pairs, options = {}) {
      const map = env.name(new Map(pairs), label)
      Object.defineProperty(map, 'entries', {
        configurable: true,
        value() {
          env.note(`${label}.entries recv=${env.who(this)}`)
          return env.iter(label, Map.prototype.entries.call(this), options)
        },
      })
      return map
    },
    loggedSet(label, items, options = {}) {
      const set = env.name(new Set(items), label)
      Object.defineProperty(set, 'values', {
        configurable: true,
        value() {
          env.note(`${label}.values recv=${env.who(this)}`)
          return env.iter(label, Set.prototype.values.call(this), options)
        },
      })
      return set
    },
    // Record whose properties are logged getters; `effects[key]` runs inside the getter.
    getters(label, entries, effects = {}, prototype = Object.prototype) {
      const record = env.name(Object.create(prototype), label)
      for (const [key, value] of entries)
        Object.defineProperty(record, key, {
          configurable: true,
          enumerable: true,
          get() {
            env.note(`${label}.${key} getter this=${env.who(this)}`)
            if (effects[key]) return effects[key](value)
            return value
          },
        })
      return record
    },
  }
  return env
}

function describeError(error, env) {
  const index = env.thrown.indexOf(error)
  if (index >= 0) return { user: index, label: error.boom }
  if (error instanceof Error)
    return {
      name: error.name,
      ctor: error.constructor?.name,
      message: error.message,
      cause: error.cause === undefined ? undefined : JSON.stringify(error.cause),
    }
  return { other: String(error) }
}

function runOnce(library, build) {
  const env = makeEnv()
  let root
  try {
    root = build(env)
  } catch (error) {
    return JSON.stringify({ buildError: String(error) })
  }
  env.note('--- stringify')
  let result
  try {
    result = { text: library.stringify(root) }
  } catch (error) {
    result = { error: describeError(error, env) }
  }
  return JSON.stringify({ result, log: env.log })
}

let failures = 0
let passes = 0
function compare(label, build) {
  const left = runOnce(A, build)
  const right = runOnce(B, build)
  if (left !== right) {
    failures++
    if (failures <= 20) {
      const l = JSON.parse(left)
      const r = JSON.parse(right)
      console.log(`MISMATCH ${label}`)
      console.log('  base:', JSON.stringify(l.result))
      console.log('  cand:', JSON.stringify(r.result))
      const ll = l.log ?? []
      const rl = r.log ?? []
      for (let i = 0; i < Math.max(ll.length, rl.length); i++)
        if (ll[i] !== rl[i]) {
          console.log(`  first log difference at ${i}: base=${ll[i]} cand=${rl[i]}`)
          break
        }
    }
  } else passes++
}

const hasTemporal = typeof globalThis.Temporal === 'object'

// ---------------------------------------------------------------- handwritten cases
const cases = {
  'arrays: empty / holes / trailing / first present not 0'(env) {
    const trailing = [1, 2, , ]
    const longHole = []
    longHole[3] = { x: 1 }
    longHole.length = 10
    return [[], [, 1], [1, , 2], trailing, new Array(5), longHole, [, { y: 2 }], [{ z: 3 }, , ]]
  },
  'array proxy: length/has/get observation order'(env) {
    const inner = env.watch([1, , { a: 1 }, , 'x'], 'arr')
    return env.watch({ inner, again: inner }, 'root')
  },
  'array grows from child getter (child pushes a frame)'(env) {
    const array = env.watch([], 'arr')
    const child = env.getters('child', [['g', 1]], {
      g(value) {
        array.push({ late: true }, 5)
        return value
      },
    })
    array.push(child, 'tail')
    return array
  },
  'array grows from element get trap (primitive child, in place)'(env) {
    const target = [1, 2, 3]
    let grown = false
    const array = new Proxy(target, {
      get(t, key, receiver) {
        env.note(`arr.get ${describeKey(key)}`)
        if (key === '1' && !grown) {
          grown = true
          t.push(4, { nested: 1 })
        }
        return Reflect.get(t, key, receiver)
      },
      has(t, key) {
        env.note(`arr.has ${describeKey(key)}`)
        return Reflect.has(t, key)
      },
    })
    return array
  },
  'array shrinks from child getter'(env) {
    const array = env.watch([], 'arr')
    array.push(
      env.getters('child', [['g', 1]], {
        g(value) {
          array.length = 0
          return value
        },
      }),
      1,
      2,
    )
    return array
  },
  'array shrink then regrow with holes, from a nested frame'(env) {
    const array = []
    array.push(
      1,
      env.getters('child', [['g', {}]], {
        g(value) {
          array.length = 1
          array[4] = 'four'
          return value
        },
      }),
      2,
    )
    return env.watch(array, 'arr')
  },
  'array proxy: length becomes an object with logged valueOf'(env) {
    let reads = 0
    const target = [1, { a: 1 }, 3]
    return new Proxy(target, {
      get(t, key, receiver) {
        env.note(`arr.get ${describeKey(key)}`)
        if (key === 'length' && reads++ > 0)
          return {
            valueOf() {
              env.note('length.valueOf')
              return reads < 4 ? 3 : 1
            },
          }
        return Reflect.get(t, key, receiver)
      },
    })
  },
  'array proxy: huge length after initial read hits index bound'(env) {
    let reads = 0
    const target = []
    return new Proxy(target, {
      get(t, key, receiver) {
        if (key === 'length') return reads++ === 0 ? 0 : 2 ** 53
        return Reflect.get(t, key, receiver)
      },
      has(t, key) {
        // jump the cursor quickly: report present only near the bound is not possible;
        // keep it cheap by throwing after a few probes.
        if (Number(key) > 3) throw env.boom('has-stop')
        env.note(`has ${describeKey(key)}`)
        return false
      },
    })
  },
  'array: self reference and aliasing'(env) {
    const a = []
    const shared = { s: 1 }
    a.push(a, shared, [shared, a], shared)
    return a
  },
  'shapes: prefixes, permutations, separator-like and lone-surrogate keys'(env) {
    const make = (keys) => {
      const o = {}
      for (const k of keys) Object.defineProperty(o, k, { value: k.length, enumerable: true, configurable: true, writable: true })
      return o
    }
    const nul = (keys) => {
      const o = Object.create(null)
      for (const k of keys) o[k] = 0
      return o
    }
    return [
      make(['a', 'b']),
      make(['a']),
      make(['a', 'b']),
      make([]),
      make(['b', 'a']),
      make(['a,b']),
      make(['a', 'b', 'c']),
      make(['a"', 'b']),
      make(['a', '"b']),
      make(['\uD800']),
      make(['\uD800', '\uDC00']),
      make(['𐀀']),
      make(['__proto__']),
      make(['']),
      make(['', '']).constructor === Object ? make(['', 'x']) : null,
      nul(['a', 'b']),
      nul([]),
      make(['0', '1', 'length']),
    ]
  },
  'record proxy: ownKeys twice, getOwnPropertySymbols after reads'(env) {
    const target = { a: 1, b: { c: 2 }, d: [3] }
    return env.watch(target, 'rec')
  },
  'record: getter adds a symbol key before getOwnPropertySymbols'(env) {
    const record = env.getters('rec', [['a', 1], ['b', { inner: true }]], {
      b(value) {
        record[Symbol('late')] = 1
        return value
      },
    })
    return { outer: record }
  },
  'record: getter deletes later key and adds new keys'(env) {
    const record = env.getters('rec', [['a', { x: 1 }], ['b', 2], ['c', 3]], {
      a(value) {
        delete record.b
        record.z = 9
        return value
      },
    })
    return record
  },
  'record: getter receiver is proxy'(env) {
    const target = env.getters('target', [['g', 1], ['h', { k: 2 }]])
    return env.watch(target, 'proxy')
  },
  'map: logged entries/next/destructuring, object keys and values'(env) {
    const k = env.name({ key: 1 }, 'k')
    const v = env.name({ value: 1 }, 'v')
    return env.loggedMap('m', [[k, v], ['p', 1], [v, k], [1, [k]]], { wrapEntry: true })
  },
  'map: key tokenization throws (unsupported) -> IteratorClose'(env) {
    return env.loggedMap('m', [['ok', 1], [() => 1, 2]])
  },
  'map: value tokenization throws (symbol) -> IteratorClose'(env) {
    return env.loggedMap('m', [['ok', 1], ['bad', Symbol('s')]])
  },
  'map: key pushes frame, then value throws'(env) {
    return env.loggedMap('m', [[{ objectKey: true }, () => 2]])
  },
  'map: key pushes frame whose getter throws (nested)'(env) {
    const key = env.getters('key', [['g', 1]], {
      g() {
        throw env.boom('key-getter')
      },
    })
    return env.loggedMap('m', [[key, 'value']])
  },
  'map: value pushes frame whose getter throws (nested)'(env) {
    const value = env.getters('value', [['g', 1]], {
      g() {
        throw env.boom('value-getter')
      },
    })
    return env.loggedMap('m', [['key', value]])
  },
  'map: getPrototypeOf trap throws while recognizing key'(env) {
    const key = new Proxy(
      {},
      {
        getPrototypeOf() {
          env.note('key.getPrototypeOf')
          throw env.boom('key-proto')
        },
      },
    )
    return env.loggedMap('m', [['first', 1], [key, 2]])
  },
  'map: getPrototypeOf trap throws while recognizing value'(env) {
    const value = new Proxy(
      {},
      {
        getPrototypeOf() {
          env.note('value.getPrototypeOf')
          throw env.boom('value-proto')
        },
      },
    )
    return env.loggedMap('m', [[{ k: 1 }, value]])
  },
  'map: return throws, original error preserved'(env) {
    return env.loggedMap('m', [['bad', () => 1]], { throwReturn: true })
  },
  'map: next throws, no IteratorClose'(env) {
    return env.loggedMap('m', [['a', { x: 1 }], ['b', 2]], { throwNextAt: 1 })
  },
  'map: self key and self value, live insertion from nested getter'(env) {
    const map = env.loggedMap('m', [])
    map.set(map, map)
    map.set(
      'getter',
      env.getters('g', [['x', 1]], {
        x(value) {
          map.set('late', { added: true })
          map.delete('never')
          return value
        },
      }),
    )
    map.set('never', 0)
    return map
  },
  'map: entries own override returning non-object iterator'(env) {
    const map = new Map([[1, 2]])
    Object.defineProperty(map, 'entries', {
      value() {
        env.note('entries')
        return { [Symbol.iterator]: () => 42 }
      },
    })
    return [map]
  },
  'map: entry is not iterable'(env) {
    const map = new Map([[1, 2]])
    Object.defineProperty(map, 'entries', {
      value() {
        return env.iter('m', [[1, 2], 7][Symbol.iterator]())
      },
    })
    return map
  },
  'map proxy (brand failure inside entries)'(env) {
    return { m: env.watch(new Map([[1, 2]]), 'mp') }
  },
  'set: logged values, nested sets, alias, self'(env) {
    const inner = env.loggedSet('inner', [1, { a: 1 }])
    const outer = env.loggedSet('outer', [inner, 'x'])
    outer.add(outer)
    inner.add(outer)
    return [outer, inner]
  },
  'set: child unsupported -> IteratorClose'(env) {
    return env.loggedSet('s', [1, class Foo {}])
  },
  'set: nested frames throw -> both iterators closed in stack order'(env) {
    const deep = env.getters('deep', [['g', 1]], {
      g() {
        throw env.boom('deep')
      },
    })
    const inner = env.loggedSet('inner', [0, [deep]])
    const middle = env.loggedMap('middle', [['k', inner]])
    return env.loggedSet('outer', ['first', middle, 'never'])
  },
  'set: live add during iteration from nested getter'(env) {
    const set = env.loggedSet('s', [])
    set.add(
      env.getters('g', [['x', 1]], {
        x(value) {
          set.add({ late: 1 })
          set.add('prim')
          return value
        },
      }),
    )
    return set
  },
  'set: return missing (null) and non-callable'(env) {
    const set = new Set([1, () => 1])
    Object.defineProperty(set, 'values', {
      value() {
        const inner = Set.prototype.values.call(this)
        return { next: () => inner.next(), return: null }
      },
    })
    return set
  },
  'natives: Date, invalid Date, URL ownership both orders, params alone'(env) {
    const url = new URL('https://example.com/a?b=1&c=2')
    const url2 = new URL('https://example.com/?z=9')
    const params = new URLSearchParams('q=1')
    return {
      d: new Date(5),
      bad: new Date(NaN),
      p: url.searchParams,
      u: url,
      u2: url2,
      p2: url2.searchParams,
      lone: params,
      again: [url, url2.searchParams],
    }
  },
  'natives: views before/after buffer, DataView, aliases'(env) {
    const buffer = new ArrayBuffer(8)
    new Uint8Array(buffer).set([1, 2, 3, 4, 5, 6, 7, 8])
    const view = new Uint8Array(buffer, 2, 4)
    const data = new DataView(buffer, 1, 3)
    const other = new Float64Array(1)
    return [view, buffer, data, [data, view], other, other.buffer, new Int16Array(new ArrayBuffer(4))]
  },
  'natives: buffer seen first, then view, inside getters'(env) {
    const buffer = new ArrayBuffer(4)
    return env.getters('rec', [
      ['b', buffer],
      ['v', new Uint8Array(buffer)],
      ['d', new Date(0)],
    ])
  },
  'natives: proxy around Date fails native read'(env) {
    return [1, env.watch(new Date(0), 'dateProxy')]
  },
  'natives: Temporal (if available)'(env) {
    if (!hasTemporal) return null
    return [Temporal.PlainDate.from('2020-01-02'), Temporal.Duration.from({ hours: 1 })]
  },
  'unsupported: function, symbol, class instance, RegExp after progress'(env) {
    return [1, { a: 2 }, /x/]
  },
  'unsupported: getter returning function inside map inside array'(env) {
    return [env.loggedMap('m', [['k', env.getters('r', [['f', () => 1]])]])]
  },
  'scalars: special numbers, bigint, negative zero'(env) {
    return [NaN, Infinity, -Infinity, -0, 0, -1.5, 10n, -10n, undefined, null, true, '']
  },
  'root primitive and root leaf'(env) {
    return new Date(1)
  },
  'deep chain (no recursion overflow)'(env) {
    let node = { end: true }
    for (let i = 0; i < 20000; i++) node = i % 3 === 0 ? [node] : i % 3 === 1 ? { n: node } : new Set([node])
    return node
  },
  'wide arrays of objects and records'(env) {
    const out = []
    for (let i = 0; i < 300; i++) out.push(i % 5 === 0 ? { i, k: [i] } : i % 7 === 0 ? undefined : i)
    out.length = 400
    return out
  },
}

for (const [label, build] of Object.entries(cases)) compare(label, build)

// ---------------------------------------------------------------- seeded fuzz
function rng(seed) {
  let s = seed >>> 0 || 0x9e3779b9
  return () => {
    s ^= s << 13
    s >>>= 0
    s ^= s >>> 17
    s ^= s << 5
    s >>>= 0
    return s / 4294967296
  }
}

const vocabulary = ['a', 'b', 'c', '__proto__', '', 'x,y', '"q', 'length', '0']

function fuzzBuild(seed) {
  return (env) => {
    const random = rng(seed)
    const int = (n) => Math.floor(random() * n)
    const pick = (list) => list[int(list.length)]
    const pool = []
    const containers = []
    let counter = 0
    let sharedBuffer
    const primitive = () =>
      pick([0, 1, -1, -0, 1.5, NaN, Infinity, -Infinity, 2n, -3n, 'str', '', true, false, null, undefined])
    function native() {
      switch (int(7)) {
        case 0:
          return new Date(int(1000))
        case 1:
          return new Date(NaN)
        case 2: {
          const url = new URL(`https://e.test/?k=${int(9)}`)
          return random() < 0.5 ? url : url.searchParams
        }
        case 3:
          return new URLSearchParams(`a=${int(9)}`)
        case 4: {
          if (sharedBuffer === undefined || random() < 0.3) sharedBuffer = new ArrayBuffer(8)
          return random() < 0.5 ? sharedBuffer : new Uint8Array(sharedBuffer, int(4), 2)
        }
        case 5:
          return new DataView(new ArrayBuffer(4), 1)
        default:
          return hasTemporal ? Temporal.PlainTime.from('01:02') : new Date(1)
      }
    }
    function unsupported() {
      return pick([() => 1, Symbol('s'), new (class X {})(), /re/, new WeakMap()])
    }
    function effect() {
      // Decided at build time; executed inside a getter at traversal time.
      const r = random()
      if (r < 0.55) return undefined
      if (r < 0.65) {
        const sentinel = `throw${counter++}`
        return () => {
          throw env.boom(sentinel)
        }
      }
      if (containers.length === 0) return undefined
      const target = pick(containers)
      const action = int(6)
      const prim = primitive()
      return () => {
        env.note(`effect ${action} on ${env.who(target)}`)
        if (Array.isArray(target)) {
          if (action === 0) target.push(prim, { pushed: 1 })
          else if (action === 1) target.length = Math.max(0, target.length - 1)
          else if (action === 2) target.length += 2
          else if (action === 3) delete target[0]
          else target[target.length + 1] = { far: 1 }
        } else if (target instanceof Map) {
          if (action < 3) target.set(`late${action}`, action === 0 ? { late: 1 } : prim)
          else target.delete(target.keys().next().value)
        } else if (target instanceof Set) {
          if (action < 3) target.add(action === 0 ? { late: 1 } : prim)
          else target.delete(target.values().next().value)
        } else if (target && typeof target === 'object') {
          if (action < 2) delete target[Object.keys(target)[0]]
          else if (action === 2) target[Symbol('sym')] = 1
          else Object.defineProperty(target, `n${action}`, { value: 1, enumerable: true, configurable: true })
        }
      }
    }
    function value(depth) {
      const r = random()
      if (pool.length !== 0 && r < 0.12) return pick(pool)
      if (depth > 4 || r < 0.42) return primitive()
      if (r < 0.5) return native()
      if (r < 0.515) return unsupported()
      return container(depth + 1)
    }
    function wrap(object, label) {
      return random() < 0.3 ? env.watch(object, label) : env.name(object, label)
    }
    function container(depth) {
      const label = `n${counter++}`
      const kind = int(5)
      if (kind === 0 || kind === 1) {
        const record = kind === 0 ? {} : Object.create(null)
        const visible = wrap(record, label)
        pool.push(visible)
        containers.push(record)
        const count = int(4)
        const keys = []
        for (let i = 0; i < count; i++) {
          const key = pick(vocabulary)
          if (!keys.includes(key)) keys.push(key)
        }
        for (const key of keys) {
          const child = value(depth)
          const run = effect()
          if (random() < 0.4)
            Object.defineProperty(record, key, {
              configurable: true,
              enumerable: true,
              get() {
                env.note(`${label}.${key} getter this=${env.who(this)}`)
                if (run) run()
                return child
              },
            })
          else Object.defineProperty(record, key, { configurable: true, enumerable: true, writable: true, value: child })
        }
        return visible
      }
      if (kind === 2) {
        const array = []
        const visible = wrap(array, label)
        pool.push(visible)
        containers.push(array)
        const length = int(6)
        for (let i = 0; i < length; i++) if (random() >= 0.25) array[i] = value(depth)
        if (random() < 0.2) array.length += int(3)
        if (random() < 0.3 && length > 0) {
          const index = int(length)
          const child = value(depth)
          const run = effect()
          Object.defineProperty(array, index, {
            configurable: true,
            enumerable: true,
            get() {
              env.note(`${label}[${index}] getter this=${env.who(this)}`)
              if (run) run()
              return child
            },
          })
        }
        return visible
      }
      if (kind === 3) {
        const options = {
          wrapEntry: random() < 0.3,
          throwReturn: random() < 0.1,
          noReturn: random() < 0.1,
          throwNextAt: random() < 0.05 ? int(3) : undefined,
        }
        const logged = random() < 0.6
        const map = logged ? env.loggedMap(label, [], options) : env.name(new Map(), label)
        pool.push(map)
        containers.push(map)
        const count = int(4)
        for (let i = 0; i < count; i++) map.set(random() < 0.5 ? primitive() : value(depth), value(depth))
        return map
      }
      const options = {
        throwReturn: random() < 0.1,
        noReturn: random() < 0.1,
        throwNextAt: random() < 0.05 ? int(3) : undefined,
      }
      const logged = random() < 0.6
      const set = logged ? env.loggedSet(label, [], options) : env.name(new Set(), label)
      pool.push(set)
      containers.push(set)
      const count = int(4)
      for (let i = 0; i < count; i++) set.add(value(depth))
      return set
    }
    return random() < 0.1 ? value(0) : container(0)
  }
}

for (let seed = 1; seed <= fuzzCount; seed++) compare(`fuzz seed ${seed}`, fuzzBuild(seed))

console.log(`${passes} identical, ${failures} mismatched`)
process.exitCode = failures === 0 ? 0 : 1
