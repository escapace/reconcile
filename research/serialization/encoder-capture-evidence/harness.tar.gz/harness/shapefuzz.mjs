// Shape-interning fuzz: random record key sequences (prefixes, extensions, permutations,
// lone surrogates); candidate wire must equal baseline wire byte for byte.
const [b, c, n = '3000'] = process.argv.slice(2)
const A = await import(b), B = await import(c)
let seed = 7; const rnd = (k) => ((seed = (seed * 1103515245 + 12345) >>> 0) % k)
const alphabet = ['a', 'b', 'c', 'd', '\ud800', '0', '1', '__proto__', '', 'a,b', '"']
let total = 0
for (let t = 0; t < +n; t++) {
  const records = []
  const count = 1 + rnd(12)
  for (let r = 0; r < count; r++) {
    const o = {}; const len = rnd(7)
    for (let k = 0; k < len; k++) Object.defineProperty(o, alphabet[rnd(alphabet.length)], { value: k, enumerable: true, configurable: true, writable: true })
    records.push(o)
  }
  // Repeat some records' shapes in a different order to exercise lookups after splits.
  for (let r = 0; r < count; r++) if (rnd(2)) records.push(Object.assign({}, records[rnd(count)]))
  const x = A.stringify(records), y = B.stringify(records)
  if (x !== y) { console.error('MISMATCH', JSON.stringify(records.map(Object.keys)), x, y); process.exit(1) }
  total++
}
console.log('shape fuzz identical:', total)
