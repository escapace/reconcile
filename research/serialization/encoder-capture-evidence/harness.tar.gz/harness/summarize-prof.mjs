// Self-time by function (top N) from a .cpuprofile
import { readFileSync } from 'node:fs'
const p = JSON.parse(readFileSync(process.argv[2], 'utf8')); const N = +(process.argv[3] ?? 18)
const dt = new Map(); const ids = new Map(p.nodes.map((n) => [n.id, n]))
for (let i = 0; i < p.samples.length; i++) dt.set(p.samples[i], (dt.get(p.samples[i]) ?? 0) + (p.timeDeltas[i] ?? 0))
const self = new Map(); let total = 0
for (const [id, t] of dt) { const n = ids.get(id); const k = `${n.callFrame.functionName || '(anon)'} ${n.callFrame.url.split('/').pop()}:${n.callFrame.lineNumber}`; self.set(k, (self.get(k) ?? 0) + t); total += t }
for (const [k, t] of [...self].sort((a, b) => b[1] - a[1]).slice(0, N)) console.log((t / total * 100).toFixed(1).padStart(5) + '%', k)
