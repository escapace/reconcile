#!/usr/bin/env python3
"""Export a round's raw samples as compact per-batch CSV (gzip) with GC events attributed by start time."""
import json, sys, gzip, csv, io, pathlib
src, dst = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
out = io.StringIO(); w = csv.writer(out)
w.writerow(['arm', 'rep', 'pos', 'fixture', 'seed', 'block', 'warm', 'op', 'count', 'wall_ms', 'cpu_ms', 'gc_count', 'gc_ms', 'gc_max_ms', 'wire', 'chars', 'alloc_bytes_per_call'])
for line in open(src / 'samples.jsonl'):
    r = json.loads(line)
    if r['exit'] != 0: w.writerow([r['arm'], r['rep'], r['pos'], r['fixture'], r['seed'], 'FAILED', '', '', '', '', '', '', '', '', '', '', '']); continue
    d = r['data']; gcs = d['gcs']
    for b in d['batches']:
        g = [x for x in gcs if b['start'] <= x[0] < b['start'] + b['wall']]
        f = d['fixtures'][b['fixture']]
        w.writerow([r['arm'], r['rep'], r['pos'], b['fixture'], r['seed'], b['block'], int(b['warm']), b['op'], b['count'], f"{b['wall']:.4f}", f"{b['cpu']:.3f}",
                    len(g), f"{sum(x[1] for x in g):.3f}", f"{max((x[1] for x in g), default=0):.3f}", f['wire'], f['chars'], f"{f.get('alloc', {}).get(b['op'], 0):.0f}"])
dst.write_bytes(gzip.compress(out.getvalue().encode(), 9))
print(dst.name, len(out.getvalue()), dst.stat().st_size)
