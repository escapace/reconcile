#!/usr/bin/env python3
"""Summarize a round: per fixture/op paired ratios vs a reference arm across reps.
usage: analyze.py <round dir> [--ref baseline] [--ops enc,encc,dec,rt] [--json out.json]"""
import json, sys, statistics as st, argparse, math, pathlib
ap = argparse.ArgumentParser(); ap.add_argument('dir'); ap.add_argument('--ref', default='baseline'); ap.add_argument('--ops', default='enc,encc,dec,rt'); ap.add_argument('--json'); ap.add_argument('--stat', default='median', choices=['median', 'mean'])
a = ap.parse_args(); d = pathlib.Path(a.dir)
recs = [json.loads(l) for l in open(d / 'samples.jsonl')]
per = {}  # (arm, rep, fixture, op) -> list of per-call ms
meta = {}
for r in recs:
    if r['exit'] != 0: print('FAILED', r['arm'], r['fixture'], r.get('stderr', '')[-300:]); continue
    D = r['data']
    for b in D['batches']:
        if b['warm']: continue
        per.setdefault((r['arm'], r['rep'], b['fixture'], b['op']), []).append(b['wall'] / b['count'])
    for f, info in D['fixtures'].items(): meta.setdefault((r['arm'], f), []).append(info)
arms = sorted({k[0] for k in per}); fixtures = list(dict.fromkeys(k[2] for k in per)); ops = a.ops.split(',')
reps = sorted({k[1] for k in per})
def stat(xs): return st.median(xs) if a.stat == 'median' else st.fmean(xs)
summary = {}
others = [x for x in arms if x != a.ref]
print(f"stat={a.stat}; ratio=arm/{a.ref} per rep -> median [min,max]; abs = {a.ref} median us/call")
hdr = f"{'fixture':18} {'op':5} {'ref_us':>9} " + ' '.join(f"{o:>22}" for o in others)
print(hdr)
for f in fixtures:
    for op in ops:
        row = {}; ref_abs = [stat(per[(a.ref, r, f, op)]) for r in reps if (a.ref, r, f, op) in per]
        if not ref_abs: continue
        cells = []
        for o in others:
            rs = [stat(per[(o, r, f, op)]) / stat(per[(a.ref, r, f, op)]) for r in reps if (o, r, f, op) in per and (a.ref, r, f, op) in per]
            if not rs: cells.append(f"{'n/a':>22}"); continue
            gm = math.exp(st.fmean(math.log(x) for x in rs))
            row[o] = {'ratios': rs, 'median': st.median(rs), 'min': min(rs), 'max': max(rs), 'geomean': gm,
                      'abs_us': [1000 * stat(per[(o, r, f, op)]) for r in reps if (o, r, f, op) in per],
                      'tail_max_us': max(1000 * max(per[(o, r, f, op)]) for r in reps if (o, r, f, op) in per)}
            cells.append(f"{st.median(rs):6.3f} [{min(rs):5.3f},{max(rs):5.3f}]")
        summary[f + ':' + op] = {'ref_abs_us': [1000 * x for x in ref_abs], 'ref_tail_max_us': max(1000 * max(per[(a.ref, r, f, op)]) for r in reps if (a.ref, r, f, op) in per), 'arms': row}
        print(f"{f:18} {op:5} {1000*st.median(ref_abs):9.1f} " + ' '.join(cells))
# wire/alloc
print('\nwire chars / alloc bytes per call (enc, dec) by arm')
for f in fixtures:
    line = f"{f:18}"
    for arm in arms:
        infos = meta.get((arm, f), [])
        if not infos: continue
        wires = {i['wire'] for i in infos}
        al = infos[0].get('alloc', {})
        line += f" | {arm}: {infos[0]['chars']}{'' if len(wires)==1 else ' WIRE-UNSTABLE'} enc {al.get('enc',0)/1024:.0f}K dec {al.get('dec',0)/1024:.0f}K"
    print(line)
if a.json: pathlib.Path(a.json).write_text(json.dumps(summary, indent=1))
