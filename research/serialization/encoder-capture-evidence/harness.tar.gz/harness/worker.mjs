// One fresh process = one arm x one fixture (isolated mode) or one arm x all fixtures (history mode).
// Fixed call counts come from a frozen manifest; every batch is retained with wall/CPU/GC data.
// usage: node worker.mjs <codec.mjs> <manifest.json> <fixture|@history> <seed>
import { readFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { PerformanceObserver, performance } from 'node:perf_hooks'
import v8 from 'node:v8'
import { fixtures, equivalent } from './corpus.mjs'
const [codecPath, manifestPath, target, seedText] = process.argv.slice(2)
const manifest = JSON.parse(readFileSync(manifestPath, 'utf8'))
const { stringify, parse } = await import(codecPath)
const gcs = []
new PerformanceObserver((list) => { for (const e of list.getEntries()) gcs.push([e.startTime, e.duration, e.detail?.kind ?? 0]) }).observe({ entryTypes: ['gc'] })
const OPS = manifest.ops // e.g. ['enc','encc','dec','rt']
// Complete consumption: native UTF-16 -> UTF-8 transcoding reads every code unit and flattens ropes.
// A JS charCodeAt loop was bimodal across processes (consumer JIT tiering), so it is not used.
const encoder = new TextEncoder(); let scratch = new Uint8Array(1 << 16)
function consume(text) { if (scratch.length < text.length * 3) scratch = new Uint8Array(text.length * 3); return encoder.encodeInto(text, scratch).written }
function prepare(name) {
  const value = fixtures[name]()
  const text = stringify(value)
  equivalent(value, parse(text)) // independent graph-bijection fidelity check before timing
  const second = stringify(value)
  if (second !== text) throw new Error('nondeterministic wire')
  return { name, value, text, wire: createHash('sha256').update(text).digest('hex').slice(0, 16), chars: text.length, utf8: Buffer.byteLength(text) }
}
let sink = 0
function batch(f, op, count) {
  const { value, text } = f
  const c0 = process.cpuUsage(); const t0 = performance.now()
  if (op === 'enc') for (let i = 0; i < count; i++) sink ^= stringify(value).length
  else if (op === 'encc') for (let i = 0; i < count; i++) sink ^= consume(stringify(value))
  else if (op === 'dec') for (let i = 0; i < count; i++) sink ^= parse(text) === undefined ? 1 : 0
  else if (op === 'rt') for (let i = 0; i < count; i++) sink ^= parse(stringify(value)) === undefined ? 1 : 0
  const t1 = performance.now(); const c1 = process.cpuUsage(c0)
  return { op, count, start: t0, wall: t1 - t0, cpu: (c1.user + c1.system) / 1000 }
}
function allocation(f, op, count) {
  // JS-heap bytes allocated per call: used-heap delta plus bytes reclaimed by each GC in between.
  const profiler = new v8.GCProfiler(); const before = v8.getHeapStatistics().used_heap_size
  profiler.start(); batch(f, op, count); const stats = profiler.stop(); const after = v8.getHeapStatistics().used_heap_size
  let freed = 0; for (const s of stats.statistics) freed += s.beforeGC.heapStatistics.usedHeapSize - s.afterGC.heapStatistics.usedHeapSize
  return (after - before + freed) / count
}
// Deterministic PRNG for op rotation offsets (recorded by seed).
let seed = Number(seedText) >>> 0 || 1
const rand = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 2 ** 32)
const names = target === '@history' ? manifest.historyOrder : [target]
const prepared = names.map(prepare)
const out = { codec: codecPath, target, seed: Number(seedText), node: process.version, fixtures: {}, batches: [], gcs }
for (const f of prepared) out.fixtures[f.name] = { wire: f.wire, chars: f.chars, utf8: f.utf8 }
const { warmup, timed } = manifest
const offset = Math.floor(rand() * OPS.length)
for (let b = 0; b < warmup + timed; b++)
  for (const f of prepared)
    for (let k = 0; k < OPS.length; k++) {
      const op = OPS[(k + b + offset) % OPS.length]
      const r = batch(f, op, manifest.counts[f.name][op])
      r.fixture = f.name; r.block = b; r.warm = b < warmup
      out.batches.push(r)
    }
if (manifest.allocation) for (const f of prepared) { out.fixtures[f.name].alloc = {}; for (const op of OPS) out.fixtures[f.name].alloc[op] = allocation(f, op, manifest.counts[f.name][op]) }
await new Promise((r) => setTimeout(r, 5)) // flush GC performance entries
out.sink = sink
process.stdout.write(JSON.stringify(out) + '\n')
