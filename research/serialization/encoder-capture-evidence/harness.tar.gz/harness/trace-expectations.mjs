const { stringify } = await import(process.argv[2])
function spy(target, label, log) {
  return new Proxy(target, {
    get(t, k, r) { log.push(`get ${label}.${String(k)}`); return Reflect.get(t, k, r) },
    has(t, k) { log.push(`has ${label}.${String(k)}`); return Reflect.has(t, k) },
    ownKeys(t) { log.push(`ownKeys ${label}`); return Reflect.ownKeys(t) },
    getPrototypeOf(t) { log.push(`proto ${label}`); return Reflect.getPrototypeOf(t) },
  })
}
{ const log = []
  const value = spy({ a: spy([1, , spy({ b: 2 }, 'inner', log)], 'list', log), c: 3 }, 'root', log)
  const text = stringify(value); console.log('A', JSON.stringify(text), JSON.stringify(log)) }
{ const log = []; const failure = new Error('key')
  const map = new Map(); let step = 0
  map.entries = () => ({ [Symbol.iterator]() { return this }, next() { log.push('next'); step++; return step === 1 ? { done: false, value: [{ get k() { log.push('key getter'); return 1 } }, { get v() { log.push('value getter'); return 2 } }] } : step === 2 ? { done: false, value: [{ get k() { log.push('throwing key'); throw failure } }, 3] } : { done: true } }, return() { log.push('return'); return {} } })
  let caught; try { stringify(map) } catch (e) { caught = e === failure } console.log('B', caught, JSON.stringify(log)) }
{ const log = []; const list = [1]
  list.push({ get grow() { log.push('grow'); list.push('tail'); return 2 } })
  console.log('C', JSON.stringify(stringify(spy(list, 'list', log))), JSON.stringify(log)) }
