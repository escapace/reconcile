// OUT-OF-CONTRACT probe (README: "Serialization assumes unmodified standard built-ins and
// prototypes ... inherited toJSON hooks are outside this contract"). Differences here are
// informational: they show which private intrinsic uses changed, not contract violations.
// Usage: node out-of-contract-intrinsics.mjs <base.mjs> <cand.mjs>
const [base, cand] = process.argv.slice(2)
const A = await import(base)
const B = await import(cand)

function probe(label, install, build) {
  const results = []
  for (const library of [A, B]) {
    const log = []
    const restore = install(log)
    let out
    try {
      out = library.stringify(build())
    } catch (error) {
      out = `throw ${error?.message}`
    } finally {
      restore()
    }
    results.push(JSON.stringify({ out, log }))
  }
  console.log(`${results[0] === results[1] ? 'same' : 'DIFFERENT'}  ${label}`)
  if (results[0] !== results[1]) console.log('  base:', results[0], '\n  cand:', results[1])
}

// 1. Array spread in the old row construction uses the array iterator protocol.
probe(
  'patched %ArrayIteratorPrototype%.next (old spread observed it)',
  (log) => {
    const proto = Object.getPrototypeOf([][Symbol.iterator]())
    const original = proto.next
    proto.next = function () {
      log.push('next')
      return original.call(this)
    }
    return () => {
      proto.next = original
    }
  },
  () => [[1, 2], [3]],
)

// 2. JSON.stringify(keys) in the old shape memo looked up toJSON on each key array.
probe(
  'Object.prototype.toJSON getter (old shape memo observed it per record)',
  (log) => {
    Object.defineProperty(Object.prototype, 'toJSON', {
      configurable: true,
      get() {
        log.push('toJSON')
        return undefined
      },
    })
    return () => {
      delete Object.prototype.toJSON
    }
  },
  () => [{ a: 1 }, { a: 2 }, { b: 3 }],
)

// 3. Map.prototype.get call counts changed (one lookup per key in the trie).
probe(
  'patched Map.prototype.get call count',
  (log) => {
    const original = Map.prototype.get
    Map.prototype.get = function (key) {
      log.push('get')
      return original.call(this, key)
    }
    return () => {
      Map.prototype.get = original
    }
  },
  () => ({ a: 1, b: 2, c: { a: 1, b: 2 } }),
)
