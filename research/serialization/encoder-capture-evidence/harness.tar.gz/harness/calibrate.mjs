// Freeze fixed call counts per fixture/op from the baseline (one process per fixture). Run once.
// usage: node calibrate.mjs <baseline codec> <fixture> <targetMs>  -> prints {"fixture":..., counts}
import { fixtures } from './corpus.mjs'
const [codec, name, target] = process.argv.slice(2)
const { stringify, parse } = await import(codec)
const value = fixtures[name](); const text = stringify(value)
const ops = { enc: () => stringify(value), encc: () => { const t = stringify(value); return new TextEncoder().encodeInto(t, new Uint8Array(t.length * 3)).written }, dec: () => parse(text), rt: () => parse(stringify(value)) }
const counts = {}
for (const [op, fn] of Object.entries(ops)) {
  for (let i = 0; i < 3; i++) fn()
  let n = 0; const t0 = performance.now(); while (performance.now() - t0 < 60) { fn(); n++ }
  const per = (performance.now() - t0) / n
  counts[op] = Math.max(1, Math.round(+target / per))
}
console.log(JSON.stringify({ fixture: name, counts }))
