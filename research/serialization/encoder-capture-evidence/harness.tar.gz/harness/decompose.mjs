// Native-JSON floor vs full codec, one fixture per process (clean type feedback). Exploratory.
import { fixtures } from './corpus.mjs'
const [entry, name] = process.argv.slice(2)
const { stringify, parse } = await import(entry)
function time(fn, budget = 150) { for (let i = 0; i < 5; i++) fn(); let n = 0; const t0 = performance.now(); let t; do { fn(); n++ } while ((t = performance.now() - t0) < budget); return (t / n) * 1000 }
const value = fixtures[name](); const text = stringify(value); const tree = JSON.parse(text)
let s = 0
const enc = time(() => { s ^= stringify(value).length }), encJ = time(() => { s ^= JSON.stringify(tree).length })
const dec = time(() => { s ^= parse(text) === null }), decJ = time(() => { s ^= JSON.parse(text) === null })
console.log([name.padEnd(18), enc.toFixed(0).padStart(7), encJ.toFixed(0).padStart(7), (encJ / enc * 100).toFixed(0).padStart(4) + '%', dec.toFixed(0).padStart(7), decJ.toFixed(0).padStart(7), (decJ / dec * 100).toFixed(0).padStart(4) + '%', String(text.length).padStart(8)].join(' '))
