// Bundle an arm's {stringify, parse} for timing and size with fixed consumer options.
// usage: node build-arm.mjs <entry.js> <outdir> [--devalue-portable]
import { createRequire } from 'node:module'
import { readdirSync, writeFileSync, mkdirSync, readFileSync } from 'node:fs'
import path from 'node:path'
import { gzipSync } from 'node:zlib'
import { createHash } from 'node:crypto'
const require = createRequire(import.meta.url)
const pnpm = '/home/user/reconcile/node_modules/.pnpm'
const esbuild = require(path.join(pnpm, readdirSync(pnpm).find((d) => d.startsWith('esbuild@')), 'node_modules', 'esbuild'))
const [entry, out, flag] = process.argv.slice(2)
mkdirSync(out, { recursive: true })
const portable = flag === '--devalue-portable'
const plugins = portable ? [{ name: 'portable', setup(b) {
  b.onLoad({ filter: /devalue[\\/]src[\\/]base64\.js$/ }, (a) => {
    const text = readFileSync(a.path, 'utf8')
    const patched = text.replace(/const buffer = [^;]+;/, 'const buffer = false;')
    if (patched === text) throw new Error('portable patch failed')
    return { contents: patched, loader: 'js' }
  })
} }] : []
const sizes = {}
for (const [name, names] of [['both', 'stringify, parse'], ['encode', 'stringify'], ['decode', 'parse']]) {
  const r = await esbuild.build({
    stdin: { contents: `export { ${names} } from ${JSON.stringify(path.resolve(entry))}`, resolveDir: process.cwd(), loader: 'js' },
    bundle: true, minify: true, format: 'esm', platform: 'browser', target: 'es2020', write: false, plugins, logLevel: 'error',
  })
  const bytes = r.outputFiles[0].contents
  if (name === 'both') writeFileSync(path.join(out, 'codec.mjs'), bytes)
  sizes[name] = { minified: bytes.length, gzip: gzipSync(bytes, { level: 9 }).length, sha256: createHash('sha256').update(bytes).digest('hex') }
}
writeFileSync(path.join(out, 'sizes.json'), JSON.stringify(sizes, null, 1))
console.log(out, JSON.stringify(sizes))
